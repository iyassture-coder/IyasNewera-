# IyasNewer GetKey — marketplace starter

Backend + responsive storefront starter for **legitimate digital products/licenses you own or are authorized to distribute**.

## What works
- Responsive digital marketplace with search/category filters and product cards.
- Customer registration/login and account order history.
- Admin login, add/edit products, manage price/stock, import stock keys, view orders.
- SQLite database persisted on the server.
- Midtrans Snap payment flow is wired to server-side order creation and a signed notification handler.
- A stock key is allocated only after a verified Midtrans `settlement` or `capture` status.
- WhatsApp support link configurable by environment variable.

## Run locally (Node.js 20+)
1. Extract the ZIP and open a terminal in this folder.
2. Copy `.env.example` to `.env`.
3. Change `SESSION_SECRET` and `ADMIN_PASSWORD`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

Default admin email/password come from `.env`. Do not use the example password outside local development.

## Midtrans setup
1. Create a merchant account with Midtrans and start in **Sandbox**.
2. Put the Sandbox Server Key and Client Key in `.env`.
3. Set `BASE_URL` to the public HTTPS URL when deployed.
4. Configure the Midtrans payment notification URL to `https://YOUR-DOMAIN/api/payment/notification`.
5. Test pending, settlement, expire, and deny states in Sandbox before going live.
6. Only set `MIDTRANS_IS_PRODUCTION=true` and use production keys after your merchant account is approved and the whole flow is tested.

The notification endpoint checks Midtrans's signature key. The browser redirect alone never marks an order paid.

## Important limitations / launch checklist
- This is a starter project, not a deployed public website. You need hosting, domain/HTTPS, and environment variables.
- Product names/prices/descriptions are sample data in `server.js`; replace them with your real, authorized products.
- The key inventory starts empty. Add legitimate license keys from the admin page; never put keys in frontend JavaScript or source control.
- Customer accounts use server-side sessions. Before production, configure a persistent session store, HTTPS secure cookies, backups, logging/monitoring, and an account recovery flow.
- Admin access is protected by login, but before a high-volume production launch add CSRF protection, stronger audit logging, MFA, and formal security review.
- Payment gateway account, API credentials, and webhook URL must be configured by the site owner. Never share secret keys in chat or put them in the browser.
- This store is intended for lawful digital goods and authorized software licensing, not cheats, anti-cheat bypasses, stolen accounts, or unauthorized access.
