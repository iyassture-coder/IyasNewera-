require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const midtransClient = require('midtrans-client');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const db = new Database('iyasnewer.db');
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'Digital',
 description TEXT NOT NULL DEFAULT '', price INTEGER NOT NULL CHECK(price >= 0),
 duration TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS stock_keys (
 id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id),
 secret_value TEXT NOT NULL, order_id INTEGER, status TEXT NOT NULL DEFAULT 'available',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_code TEXT NOT NULL UNIQUE,
 user_id INTEGER NOT NULL REFERENCES users(id), total INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 payment_token TEXT, payment_url TEXT, payment_type TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 paid_at TEXT
);
CREATE TABLE IF NOT EXISTS order_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL REFERENCES orders(id),
 product_id INTEGER NOT NULL REFERENCES products(id), product_name TEXT NOT NULL,
 qty INTEGER NOT NULL, unit_price INTEGER NOT NULL
);
`);
const initialProducts = [
 ['Akses Harian','Harian','Lisensi digital resmi berdurasi 1 hari. Ganti dengan deskripsi produk milikmu.',10000,'1 hari'],
 ['Akses Mingguan','Mingguan','Lisensi digital resmi berdurasi 7 hari.',45000,'7 hari'],
 ['Akses Bulanan','Bulanan','Lisensi digital resmi berdurasi 30 hari.',120000,'30 hari'],
 ['Akses Premium','Premium','Paket premium untuk layanan digital yang kamu berhak distribusikan.',25000,'Sesuai produk']
];
if (db.prepare('SELECT COUNT(*) n FROM products').get().n === 0) {
 const ins=db.prepare('INSERT INTO products(name,category,description,price,duration) VALUES(?,?,?,?,?)');
 for (const p of initialProducts) ins.run(...p);
}
const email = (process.env.ADMIN_EMAIL || 'admin@iyasnewer.local').trim().toLowerCase();
if (!db.prepare('SELECT id FROM users WHERE email=?').get(email)) {
 const pass=process.env.ADMIN_PASSWORD || 'ChangeThis-Admin-Password-123!';
 db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)')
   .run('IyasNewer Admin',email,bcrypt.hashSync(pass,12),'admin');
 console.log(`Admin initialized: ${email}. Set ADMIN_PASSWORD in .env before use.`);
}

app.set('trust proxy', 1);
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'100kb'}));
app.use(express.urlencoded({extended:false}));
app.use(session({
 secret:process.env.SESSION_SECRET || 'dev-only-change-this-secret',
 resave:false,saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:1000*60*60*8}
}));
app.use('/api/auth',rateLimit({windowMs:15*60*1000,limit:30,standardHeaders:true,legacyHeaders:false}));
app.use(express.static(path.join(__dirname,'public')));

const snap = new midtransClient.Snap({
 isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
 serverKey: process.env.MIDTRANS_SERVER_KEY || 'SANDBOX_SERVER_KEY_NOT_CONFIGURED',
 clientKey: process.env.MIDTRANS_CLIENT_KEY || 'SANDBOX_CLIENT_KEY_NOT_CONFIGURED'
});
const hasMidtrans = !!(process.env.MIDTRANS_SERVER_KEY && process.env.MIDTRANS_CLIENT_KEY);

function requireUser(req,res,next){if(!req.session.user)return res.status(401).json({error:'Silakan login terlebih dahulu.'});next();}
function requireAdmin(req,res,next){if(!req.session.user || req.session.user.role!=='admin')return res.status(403).json({error:'Akses admin diperlukan.'});next();}
function safeUser(u){return {id:u.id,name:u.name,email:u.email,role:u.role};}
function publicProduct(p){
 const stock=db.prepare("SELECT COUNT(*) n FROM stock_keys WHERE product_id=? AND status='available'").get(p.id).n;
 return {...p,available_stock:stock};
}
function money(n){return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);}
app.get('/api/config',(req,res)=>res.json({whatsapp:(process.env.WHATSAPP_NUMBER||'').replace(/\D/g,''),paymentConfigured:hasMidtrans,midtransClientKey:process.env.MIDTRANS_CLIENT_KEY||'',midtransProduction:process.env.MIDTRANS_IS_PRODUCTION==='true',loggedIn:!!req.session.user,user:req.session.user?safeUser(req.session.user):null}));
app.get('/api/products',(req,res)=>res.json(db.prepare('SELECT * FROM products WHERE active=1 ORDER BY id DESC').all().map(publicProduct)));
app.post('/api/auth/register',async(req,res)=>{
 const name=String(req.body.name||'').trim(),mail=String(req.body.email||'').trim().toLowerCase(),pass=String(req.body.password||'');
 if(name.length<2||name.length>80||!mail.includes('@')||pass.length<10)return res.status(400).json({error:'Isi nama, email valid, dan kata sandi minimal 10 karakter.'});
 try{
  const info=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run(name,mail,await bcrypt.hash(pass,12),'customer');
  req.session.user=db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid);
  res.json({user:safeUser(req.session.user)});
 }catch(e){res.status(409).json({error:'Email sudah terdaftar atau tidak valid.'});}
});
app.post('/api/auth/login',async(req,res)=>{
 const mail=String(req.body.email||'').trim().toLowerCase(),pass=String(req.body.password||'');
 const u=db.prepare('SELECT * FROM users WHERE email=?').get(mail);
 if(!u||!await bcrypt.compare(pass,u.password_hash))return res.status(401).json({error:'Email atau kata sandi salah.'});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Gagal membuat sesi.'});req.session.user=u;res.json({user:safeUser(u)});});
});
app.post('/api/auth/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({user:req.session.user?safeUser(req.session.user):null}));

app.post('/api/orders',requireUser,(req,res)=>{
 if(!hasMidtrans)return res.status(503).json({error:'Pembayaran belum dikonfigurasi. Admin perlu mengisi kredensial Midtrans di server.'});
 const raw=Array.isArray(req.body.items)?req.body.items:[];
 const quantities=new Map();
 for(const row of raw){const id=Number(row.id),qty=Number(row.qty);if(Number.isInteger(id)&&Number.isInteger(qty)&&qty>0&&qty<=5)quantities.set(id,Math.min(5,(quantities.get(id)||0)+qty));}
 if(!quantities.size)return res.status(400).json({error:'Keranjang kosong atau jumlah tidak valid.'});
 const items=[];
 for(const [id,qty] of quantities){const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(id);if(!p)return res.status(400).json({error:'Produk tidak tersedia.'});
 const available=db.prepare("SELECT COUNT(*) n FROM stock_keys WHERE product_id=? AND status='available'").get(id).n;
 if(available<qty)return res.status(409).json({error:`Stok ${p.name} tidak cukup.`});items.push({p,qty});}
 const total=items.reduce((s,x)=>s+x.p.price*x.qty,0);
 if(total<=0||total>100000000)return res.status(400).json({error:'Total pesanan tidak valid.'});
 const orderCode='IN-'+Date.now()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase();
 const tx=db.transaction(()=>{
  const result=db.prepare('INSERT INTO orders(order_code,user_id,total,status) VALUES(?,?,?,?)').run(orderCode,req.session.user.id,total,'pending');
  for(const x of items)db.prepare('INSERT INTO order_items(order_id,product_id,product_name,qty,unit_price) VALUES(?,?,?,?,?)').run(result.lastInsertRowid,x.p.id,x.p.name,x.qty,x.p.price);
  return result.lastInsertRowid;
 });
 const orderId=tx();
 snap.createTransaction({
  transaction_details:{order_id:orderCode,gross_amount:total},
  item_details:items.map(x=>({id:String(x.p.id),price:x.p.price,quantity:x.qty,name:x.p.name.slice(0,50)})),
  customer_details:{first_name:req.session.user.name,email:req.session.user.email},
  callbacks:{finish:`${BASE_URL}/?payment=return`}
 }).then(result=>{
  db.prepare('UPDATE orders SET payment_token=?,payment_url=? WHERE id=?').run(result.token,result.redirect_url,orderId);
  res.json({orderCode,token:result.token,redirectUrl:result.redirect_url});
 }).catch(err=>{
  db.prepare("UPDATE orders SET status='payment_error' WHERE id=?").run(orderId);
  console.error('Midtrans create transaction error:',err.message);
  res.status(502).json({error:'Tidak bisa membuat pembayaran. Cek konfigurasi gateway.'});
 });
});
app.post('/api/payment/notification',async(req,res)=>{
 try{
  const n=req.body;
  if(!n.order_id||!n.status_code||!n.gross_amount||!n.signature_key)return res.status(400).send('Invalid notification');
  const expected=crypto.createHash('sha512').update(String(n.order_id)+String(n.status_code)+String(n.gross_amount)+String(process.env.MIDTRANS_SERVER_KEY||'')).digest('hex');
  if(expected!==n.signature_key)return res.status(403).send('Invalid signature');
  const order=db.prepare('SELECT * FROM orders WHERE order_code=?').get(String(n.order_id));
  if(!order)return res.status(404).send('Order not found');
  const amount=Number(n.gross_amount);
  if(amount!==order.total)return res.status(400).send('Amount mismatch');
  if(n.transaction_status==='settlement'||(n.transaction_status==='capture'&&n.fraud_status==='accept')){
   const settle=db.transaction(()=>{
    const fresh=db.prepare('SELECT * FROM orders WHERE id=?').get(order.id);
    if(fresh.status==='paid')return;
    const lines=db.prepare('SELECT * FROM order_items WHERE order_id=?').all(order.id);
    for(const line of lines){
     for(let i=0;i<line.qty;i++){
      const key=db.prepare("SELECT id FROM stock_keys WHERE product_id=? AND status='available' ORDER BY id LIMIT 1").get(line.product_id);
      if(!key)throw new Error('Stock exhausted at settlement');
      db.prepare("UPDATE stock_keys SET status='sold',order_id=? WHERE id=?").run(order.id,key.id);
     }
    }
    db.prepare("UPDATE orders SET status='paid',paid_at=CURRENT_TIMESTAMP,payment_type=? WHERE id=?").run(n.payment_type||'online',order.id);
   });
   try{settle();}catch(e){console.error('Fulfillment issue:',e.message);return res.status(409).send('Fulfillment requires admin review');}
  }else if(['expire','deny','cancel','failure'].includes(n.transaction_status)){
   db.prepare("UPDATE orders SET status=? WHERE id=? AND status='pending'").run(n.transaction_status,order.id);
  }else if(n.transaction_status==='pending'){
   db.prepare("UPDATE orders SET status='pending',payment_type=? WHERE id=? AND status='pending'").run(n.payment_type||null,order.id);
  }
  res.status(200).send('OK');
 }catch(e){console.error('Notification error:',e.message);res.status(500).send('Error');}
});
app.get('/api/orders',requireUser,(req,res)=>{
 const list=db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC').all(req.session.user.id);
 const getItems=db.prepare('SELECT product_name,qty,unit_price FROM order_items WHERE order_id=?');
 const getKeys=db.prepare("SELECT s.secret_value,i.product_name FROM stock_keys s JOIN order_items i ON i.order_id=s.order_id AND i.product_id=s.product_id WHERE s.order_id=? AND s.status='sold'");
 res.json(list.map(o=>({...o,items:getItems.all(o.id),keys:o.status==='paid'?getKeys.all(o.id):[]})));
});
app.get('/api/admin/orders',requireAdmin,(req,res)=>{
 const list=db.prepare(`SELECT o.*,u.name,u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC`).all();
 res.json(list.map(o=>({...o,items:db.prepare('SELECT product_name,qty,unit_price FROM order_items WHERE order_id=?').all(o.id)})));
});
app.post('/api/admin/products',requireAdmin,(req,res)=>{
 const {name,category,description,price,duration,active}=req.body;
 const p=String(name||'').trim(),cat=String(category||'Digital').trim(),desc=String(description||'').trim(),dur=String(duration||'').trim(),pr=Number(price);
 if(p.length<2||!Number.isInteger(pr)||pr<0||pr>100000000)return res.status(400).json({error:'Nama produk atau harga tidak valid.'});
 const info=db.prepare('INSERT INTO products(name,category,description,price,duration,active) VALUES(?,?,?,?,?,?)').run(p,cat,desc,pr,dur,active===false?0:1);
 res.json({product:publicProduct(db.prepare('SELECT * FROM products WHERE id=?').get(info.lastInsertRowid))});
});
app.put('/api/admin/products/:id',requireAdmin,(req,res)=>{
 const id=Number(req.params.id),{name,category,description,price,duration,active}=req.body,pr=Number(price);
 if(!Number.isInteger(id)||String(name||'').trim().length<2||!Number.isInteger(pr)||pr<0)return res.status(400).json({error:'Data produk tidak valid.'});
 const info=db.prepare('UPDATE products SET name=?,category=?,description=?,price=?,duration=?,active=? WHERE id=?').run(String(name).trim(),String(category||'Digital'),String(description||''),pr,String(duration||''),active===false?0:1,id);
 if(!info.changes)return res.status(404).json({error:'Produk tidak ditemukan.'});
 res.json({product:publicProduct(db.prepare('SELECT * FROM products WHERE id=?').get(id))});
});
app.post('/api/admin/stock',requireAdmin,(req,res)=>{
 const id=Number(req.body.productId),keys=String(req.body.keys||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 if(!Number.isInteger(id)||!db.prepare('SELECT id FROM products WHERE id=?').get(id)||!keys.length)return res.status(400).json({error:'Pilih produk dan masukkan minimal satu key.'});
 if(keys.some(k=>k.length>500))return res.status(400).json({error:'Ada key terlalu panjang.'});
 const insert=db.prepare('INSERT INTO stock_keys(product_id,secret_value) VALUES(?,?)');
 const tx=db.transaction(()=>{for(const key of keys)insert.run(id,key);});tx();
 res.json({added:keys.length});
});
app.get('/api/admin/stock',requireAdmin,(req,res)=>{
 res.json(db.prepare(`SELECT p.id product_id,p.name product_name,
 SUM(CASE WHEN s.status='available' THEN 1 ELSE 0 END) available,
 SUM(CASE WHEN s.status='sold' THEN 1 ELSE 0 END) sold
 FROM products p LEFT JOIN stock_keys s ON s.product_id=p.id GROUP BY p.id ORDER BY p.id`).all());
});
app.get('/api/admin/users',requireAdmin,(req,res)=>res.json(db.prepare('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC LIMIT 200').all()));

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`IyasNewer running at ${BASE_URL}`));
